CUE LOUNGE — COMPLETE WEBSITE FILES

FILES
- index.html: website layout
- style.css: original Cue Lounge styling plus staff dashboard styles
- script.js: customer login, reservations, and staff dashboard
- staff_access_setup.sql: secure staff membership and reservation access

STAFF / ADMIN
Staff and admin are combined into ONE permission level. Create each staff member account using the normal website sign-up first. In Supabase > Authentication > Users, copy that account UUID. Open staff_access_setup.sql, run the SQL, then replace the placeholder UUID in the final INSERT and run that INSERT. Repeat for each staff account. Staff then use the Staff access link on the welcome page. They can view reservations and update pending/confirmed/cancelled status. Customers cannot grant themselves staff access.

PAYMENTS
GCash, Maya, and PayPal are payment preferences only. No payments are processed.

PUBLISHING
Upload all four files to the root of your cue-lounge GitHub repository. Enable GitHub Pages in repository Settings > Pages. Set the published HTTPS URL in Supabase Authentication > URL Configuration. This package is website source code, not legal/business certification. Never place a service_role or secret key in frontend files.
